Link con los mismos archivos de esta carpeta para visualizar el html construido.

https://github.com/camilo16955/prueba.git